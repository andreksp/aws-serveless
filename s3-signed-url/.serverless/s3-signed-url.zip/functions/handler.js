const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");
const { createPresignedPost } = require("@aws-sdk/s3-presigned-post");
const { S3Client, GetObjectCommand } =require("@aws-sdk/client-s3");

const config = require('./../config.json');
//const prePath = 'signed-url-demo/'
const prePath = ''
const clientParams = {
  region: config.REGION
}



module.exports.createGetUrl = async (event) => {

  const pathParams = event.pathParameters;
  const client = new S3Client(clientParams);
  const key = pathParams.fileKey || null;

  console.log("Key");
  console.log(key);

  if (!key) {
    throw new Error("Key not found!")
  }
  const getObjectParams = {
    Bucket: config.S3_BUCKET,
    Key: `${prePath}${key}`
  }
  console.log("S3_BUCKET");
  console.log(config.S3_BUCKET);

  console.log("PrepathKey");
  console.log(getObjectParams.Key);

  const command = new GetObjectCommand(getObjectParams);
  const url = await getSignedUrl(client, command, { expiresIn: 3600 });
  return {
    statusCode: 200,
    body: JSON.stringify(
      {
        url
      },
      null,
      2
    ),
  };
};

module.exports.createPostUrl = async (event) => {

  const client = new S3Client(clientParams);
  const key = `${prePath}${(Math.random() + 1).toString(36).substring(2)}`
  const { url, fields } = await createPresignedPost(client, {
    Bucket: config.S3_BUCKET,
    key,
    Expires: 600, //Seconds to expire
  });
  return {
    statusCode: 200,
    body: JSON.stringify(
      {
        url,
        fields
      },
      null,
      2
    ),
  };
};